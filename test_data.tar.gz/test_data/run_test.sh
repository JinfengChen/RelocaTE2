#!/bin/bash
#PBS -l nodes=1:ppn=6
#PBS -l mem=10gb
#PBS -l walltime=100:00:00
#PBS -j oe
#PBS -V
#PBS -d ./

current_dir=`pwd`
echo "$current_dir"
relocate=/rhome/cjinfeng/BigData/00.RD/RelocaTE2/scripts/relocaTE.py
repeat=$current_dir/pogo.fa
genome=$current_dir/FLY603.Chr2L.fa
ref_te=$current_dir/FLY603.Chr2L.fa.RepeatMasker.out
fq_d=$current_dir/FLY603.Chr2L.pogo.rep1_reads
#bam=$current_dir/FLY603.Chr2L.pogo.rep1_reads.bam
outdir=$current_dir/FLY603.Chr2L.pogo.rep1_RelocaTE2_outdir
aligner=blat
size=500
strain=FLY603

start=`date +%s`

#/opt/bwa/0.7.9/bin/bwa index $genome
python $relocate --te_fasta $repeat --genome_fasta $genome --fq_dir $fq_d --outdir $outdir --reference_ins $ref_te --sample $strain --size $size --step 1234567 --mismatch 2 --run --cpu 1 --aligner $aligner --verbose 2

end=`date +%s`
runtime=$((end-start))

echo "Start: $start"
echo "End: $end"
echo "Run time: $runtime"

echo "Done"
