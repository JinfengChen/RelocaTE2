rm -Rf FLY603.Chr2L.fa.a* FLY603.Chr2L.fa.bwt FLY603.Chr2L.fa.pac FLY603.Chr2L.fa.sa FLY603.Chr2L.pogo.rep1_RelocaTE2_outdir

